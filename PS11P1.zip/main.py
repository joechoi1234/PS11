#p1
def dl1(mylist):
  n = int(input("Enter number of items in list: "))
  for n in range(0,n,1):
    s = int(input("Enter integer: "))
    mylist.append(s)
  return mylist
  
def displaylist(mylist):
  for item in mylist:
      print(item)
    
mylist = []
mylist = dl1(mylist)
print(mylist)
#p2
mylist.insert(0,99)
print(mylist)
#p3
mylist[0] = 100
print(mylist)
#p4
mylist2 = [500,600,700,800,900]
print(mylist2)
mylist.extend(mylist2)
print(mylist)
#p5
mylist2.remove(800)
print(mylist2)
#p6
mylist.pop(2)
print(mylist)
#p7-9
mylist3 = ['A', 'B', 'C', 'A', 'A', 'C']
print(mylist3)
print("Count of A's in list: ", mylist3.count('A'))
print("B position in list: ", mylist3.index('B'))
#p10
has_f = 'f' in mylist3
print(("F grade in list = ", has_f))
#p11
mylist2.clear()
print("My list 2: ", mylist2)
#p12
del mylist2
#print(mylist2)
#p13-14
players = ["Rizzo", "Davis", "Baez", "Happ", "Bryan"]
players.sort()
print(players)
#p15-16
players2  = players.copy()
print(players2)
players2.reverse()
print(players2)